#include "vbx_macros.h"
#include "vectorblox_mxp_lin.h"
#include "vbx.h"
#include "vbx_types.h"
#include "vbx_port.h"
#include "vbx_test.h"
#include "vbx_common.h"
#include "vbx_port.h"
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/time.h>


#define DW 16
#define BUFFER_SIZE 4000000
#define MXP


long timestamp()
{
	struct timeval current_time;
	gettimeofday(&current_time, NULL);
	return (current_time.tv_sec * 1000000 + current_time.tv_usec);
}

void ParseCSV_Data( FILE *TM, int16_t *col1 )
{
	int i = 0;
	char buf[BUFFER_SIZE];
	while (fgets(buf, sizeof(buf), TM) != NULL) // && i< (DATA_ARRAY_SIZE)
	{
		char *tok = strtok(buf, " ,");
		while (tok != NULL ) //&& j<=VEC_LENGTH
	  	{
	  		//printf("%s \n", tok);
			col1[i] = atoi(tok); 
			tok = strtok(NULL, " ,");
			i++;
	  	}
		
	}
}

int main(int argc, char *argv[])
{
	if ( argc != 2 ) /* argc should be 2 for correct execution */
    {
        printf( "\n Please provide the matrix size (assuming square matrix) \n");
    }
    else
    {
	    #ifdef MXP
	    {
			printf("MXP Enabled\n");
			VectorBlox_MXP_Initialize("mxp0","cma");
		}
		#else
			printf("MXP Disabled, APP is running entirely on ARM\n");
		#endif
		int Image_size; 		sscanf(argv[1], "%d", &Image_size);

		printf("\n ------------------------------- New results ----------------------------\n");
		printf("\n ----------- Data Width = %d---------------Image size = %d---------\n",DW,Image_size);
		vbx_mxp_print_params();
		vbx_mxp_t * the_mxp = VBX_GET_THIS_MXP();
		printf("The scratchpad size = %d kB\n", the_mxp->scratchpad_size/1024);	
		long start_time, stop_time;
		//int16_t *vA, *vA1, *vB0, *vD, *vB1, *v_tmp, *vD1;
		int16_t *vA0, *vA1, *vB0, *vD0, *vD1, *vD2, *vD3, *temp, *v_tmp;
		int i,k,j,m;
		FILE  *RED_TM, *MAT, *f, *g; 
		RED_TM = fopen("TM_INT_sparse_8_36.csv","r");
		MAT = fopen("INP_FILE_512Mat_1296_4096.csv","r");
		if (RED_TM == NULL || MAT == NULL) 
		{
		  fprintf(stderr, "Can't open input file in.list!\n");
		  exit(1);
		}

		int16_t *DATA   = (int16_t *)vbx_shared_malloc(4096 * 1296 * sizeof(int16_t));	
		int16_t *TM     = (int16_t *)vbx_shared_malloc(8 * 36  * sizeof(int16_t));
		int16_t *Intrm_RESULT = (int16_t *)vbx_shared_malloc(36 * 32768 * sizeof(int16_t));
		int16_t *RESULT = (int16_t *)vbx_shared_malloc(8 * 32768 * sizeof(int16_t));	
	//	int16_t *tmp_zero = (int16_t *)vbx_shared_malloc( 512 *8* sizeof(int16_t));	
		int16_t *zero_array = (int16_t *)vbx_shared_malloc( 4096 * sizeof(int16_t));	

//		for(m=0;m<512*8;m++)
//		{
//			*(tmp_zero + m) = 0;
//		}
		for (m=0;m<4096;m++)
		{
			*(zero_array + m) = 0;
		}
		//int16_t *TM = (int16_t *)vbx_shared_malloc( rept_per_SP_reqrmnt * 36 * Num_coeff_rows * sizeof(int16_t));
		//int16_t *DATA = (int16_t *)vbx_shared_malloc( rept_per_SP_reqrmnt * 36 * ((num_loop_for_TM+1)/rept_per_SP_reqrmnt) * sizeof(int16_t));
		//int16_t *RESULT = (int16_t *)vbx_shared_malloc( VEC_LENGTH * sizeof(int16_t));	

		if(TM == NULL || DATA == NULL || RESULT == NULL  || zero_array == NULL)  //|| tmp_zero == NULL
		{
			printf(" Out of memory.. Cannot allocate space for Transformation matrix \n ");
			printf("------------------ Exiting appication-------------- \n");
			return -1;
		}		
		ParseCSV_Data(RED_TM,TM);
		ParseCSV_Data(MAT,DATA);

	//	int g;
/*
		g = fopen("AAA_TM_check.txt", "w");
		if (g == NULL)
		{
		    printf("Error opening file!\n");
		    exit(1);
		}
		for (k=0;k<8*36;k++)
		{
			fprintf(g, "%d\n", TM[k]);
		}
		fclose(g);


		g = fopen("AAA_Data_check.txt", "w");
		if (g == NULL)
		{
		    printf("Error opening file!\n");
		    exit(1);
		}
		for (k=0;k<(36*34560);k++)
		{
			fprintf(g, "%d\n", DATA[k]);
		}
		fclose(g);
*/
		vbx_set_vl(4096);          // 4 per lane (8 bit)
		//vbx_set_2D( 1024, 8 * sizeof(int16_t), 8 * sizeof(int16_t), 8 * sizeof(int16_t));              // 8192/8 = 1024
//---------------------------------------------------------------------------------------------
			
//	printf("Verification 0\n");
	if((NULL == (vA0 = (int16_t *)vbx_sp_malloc(4096* sizeof(int16_t))))  ||           //Va0 -> Data
	   (NULL == (vA1 = (int16_t *)vbx_sp_malloc(4096* sizeof(int16_t))))  ||			//Va1 -> Data
   	   (NULL ==	(vB0 = (int16_t *)vbx_sp_malloc(8 *36* sizeof(int16_t)))) ||				//Vb0 -> TM
 //	   (NULL ==	(vC0 = (int16_t *)vbx_sp_malloc(4096 * sizeof(int16_t)))) ||
 //	   (NULL ==	(vC1 = (int16_t *)vbx_sp_malloc(4096 * sizeof(int16_t)))) ||
   	   (NULL ==	(vD0 = (int16_t *)vbx_sp_malloc(4096 * sizeof(int16_t)))) ||	
   	   (NULL ==	(vD1 = (int16_t *)vbx_sp_malloc(4096 * sizeof(int16_t)))) ||
   	   (NULL ==	(vD2 = (int16_t *)vbx_sp_malloc(4096 * sizeof(int16_t)))) ||   	
   	   (NULL ==	(vD3 = (int16_t *)vbx_sp_malloc(4096 * sizeof(int16_t))))
   	   )   
	{
		printf("No scratchpad... exiting\n");
		return -1;
	}

	start_time = timestamp();	
//	vbx_dma_to_vector( vB0, TM  , 8*36* sizeof(int16_t));
	vbx_dma_to_vector( vA0, DATA, 4096* sizeof(int16_t));
	for(i=0;i<8;i++)
	{
	//	printf("Verification 2\n");		
		for (j = 0; j < 36; j++)
		{	
			if(i == 0)
			{
		//	printf("Verification 3\n");
				for (k=0;k<36;k++)
				{
					if(k < 35)
					{	
						vbx_dma_to_vector( vA1, DATA + (j*36*4096) + ((k+1)*4096), 4096 * sizeof(int16_t)); 
					}
					else if(j<35)
					{
						vbx_dma_to_vector( vA1, DATA+((j+1)*36*4096), 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					else if(j==35)
					{
						vbx_dma_to_vector( vA1, DATA+(12*4096), 4096* sizeof(int16_t));
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					temp = TM + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( Intrm_RESULT + (j*32768), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 1)
			{			
				for (k=0;k<6;k++)
				{
					if(k < 5)
					{	
						vbx_dma_to_vector( vA1, DATA + (j*36*4096) + ((k+1+12)*4096), 4096 * sizeof(int16_t)); 
					}
					else if(j<35)
					{
						vbx_dma_to_vector( vA1, DATA+((j+1)*36*4096) + 12*4096, 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					else if(j==35)
					{
						vbx_dma_to_vector( vA1, DATA+(8*4096), 4096* sizeof(int16_t));
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					temp = TM + 48 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( Intrm_RESULT + (j*32768) + (i*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 2)
			{			
				for (k=0;k<16;k++)
				{
					if(k < 15)
					{	
						vbx_dma_to_vector( vA1, DATA + (j*36*4096) + ((k+1+8)*4096), 4096 * sizeof(int16_t)); 
					}
					else if(j<35)
					{
						vbx_dma_to_vector( vA1, DATA+((j+1)*36*4096) + 8*4096, 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					else if(j==35)
					{
						vbx_dma_to_vector( vA1, DATA+(14*4096), 4096* sizeof(int16_t));
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					temp = TM + 80 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( Intrm_RESULT + (j*32768) + (i*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 3)
			{			
				for (k=0;k<6;k++)
				{
					if(k < 5)
					{	
						vbx_dma_to_vector( vA1, DATA + (j*36*4096) + ((k+1+14)*4096), 4096 * sizeof(int16_t)); 
					}
					else if(j<35)
					{
						vbx_dma_to_vector( vA1, DATA+((j+1)*36*4096) + 14*4096, 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					else if(j==35)
					{
						vbx_dma_to_vector( vA1, DATA, 4096* sizeof(int16_t));
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					temp = TM + 122 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( Intrm_RESULT + (j*32768) + (i*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 4)
			{			
				for (k=0;k<36;k++)
				{
					if(k < 35)
					{	
						vbx_dma_to_vector( vA1, DATA + (j*36*4096) + ((k+1)*4096), 4096 * sizeof(int16_t)); 
					}
					else if(j<35)
					{
						vbx_dma_to_vector( vA1, DATA+((j+1)*36*4096), 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					else if(j==35)
					{
						vbx_dma_to_vector( vA1, DATA+(16*4096), 4096* sizeof(int16_t));
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					temp = TM + 144 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( Intrm_RESULT + (j*32768) + (i*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 5)
			{			
				for (k=0;k<6;k++)
				{
					if(k < 5)
					{	
						vbx_dma_to_vector( vA1, DATA + (j*36*4096) + ((k+1+16)*4096), 4096 * sizeof(int16_t)); 
					}
					else if(j<35)
					{
						vbx_dma_to_vector( vA1, DATA+((j+1)*36*4096) + 16*4096, 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					else if(j==35)
					{
						vbx_dma_to_vector( vA1, DATA + (12*4096), 4096* sizeof(int16_t));
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					temp = TM + 196 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( Intrm_RESULT + (j*32768) + (i*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 6)
			{			
				for (k=0;k<16;k++)
				{
					if(k < 15)
					{	
						vbx_dma_to_vector( vA1, DATA + (j*36*4096) + ((k+1+12)*4096), 4096 * sizeof(int16_t)); 
					}
					else if(j<35)
					{
						vbx_dma_to_vector( vA1, DATA+((j+1)*36*4096) + 12*4096, 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					else if(j==35)
					{
						vbx_dma_to_vector( vA1, DATA + (18*4096), 4096* sizeof(int16_t));
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					temp = TM + 228 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( Intrm_RESULT + (j*32768) + (i*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 7)
			{			
				for (k=0;k<6;k++)
				{
					if(k < 5)
					{	
						vbx_dma_to_vector( vA1, DATA + (j*36*4096) + ((k+1+18)*4096), 4096 * sizeof(int16_t)); 
					}
					else if(j<35)
					{
						vbx_dma_to_vector( vA1, DATA+((j+1)*36*4096) + 18*4096, 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					else if(j==35)
					{
						vbx_dma_to_vector( vA1, Intrm_RESULT, 4096* sizeof(int16_t));
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
					temp = TM + 270 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( Intrm_RESULT + (j*32768) + (i*4096), vD3, 4096 * sizeof(int16_t));			
			}

		}
	}
//------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	for(j = 0; j<8;j++)	
	{
		for (k = 0;k<8;k++)
		{
			for (i = 0;i<36;i++)
			{
				if(i < 35)
				{	
					vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + ((i+1)*32768), 4096 * sizeof(int16_t)); 
				}
				else if (k<7)
				{
					vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096), 4096 * sizeof(int16_t)); 
					vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
				}
				else if (k==7 && j<7)
				{
					vbx_dma_to_vector( vA1, Intrm_RESULT + ((j+1)*4096), 4096 * sizeof(int16_t)); 
					vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
				}
				temp = TM + (k*36) + i;
				vbx(SVHS, VMUL, vD0 , *(temp), vA0);
				vbx(VVHS, VADD, vD1, vD0, vD1);
				v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;
			}
			v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
			v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
			vbx_dma_to_host( RESULT + (j*4096) + (k*32768), vD2, 4096 * sizeof(int16_t));
		}
	}
	*/
//------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------	
	
	for (j = 0;j<8;j++)	
		{	
		for(i=0;i<8;i++)
		{	
			if(i == 0)
			{
				for (k=0;k<36;k++)
				{
					if(k < 35)
					{	
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + ((k+1)*32768), 4096 * sizeof(int16_t)); 
					}
					else //if(i<7)
					{
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + (12*32768), 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
				//	else if(i==7)
				//	{
				//		vbx_dma_to_vector( vA1, Intrm_RESULT+(12*4096), 4096* sizeof(int16_t));
				//		vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
				//	}
					temp = TM + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( RESULT + (j*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 1)
			{			
				for (k=0;k<6;k++)
				{
					if(k < 5)
					{	
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + ((k+1+12)*32768), 4096 * sizeof(int16_t)); 
					}
					else //if(i<7)
					{
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + (8*32768), 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
			//		else if(i==7)
			//		{
			//			vbx_dma_to_vector( vA1, Intrm_RESULT+(8*4096), 4096* sizeof(int16_t));
			//			vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
			//		}
					temp = TM + 48 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( RESULT + (i*32768) + (j*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 2)
			{			
				for (k=0;k<16;k++)
				{
					if(k < 15)
					{	
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + ((k+1+8)*32768), 4096 * sizeof(int16_t)); 
					}
					else //if(i<7)
					{
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + (14*32768), 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
			//		else if(i==7)
			//		{
			//			vbx_dma_to_vector( vA1, Intrm_RESULT+(14*4096), 4096* sizeof(int16_t));
			//			vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
			//		}
					temp = TM + 80 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( RESULT + (i*32768) + (j*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 3)
			{			
				for (k=0;k<6;k++)
				{
					if(k < 5)
					{	
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + ((k+1+14)*32768), 4096 * sizeof(int16_t)); 
					}
					else //if(j<35)
					{
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096), 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
			//		else if(i==7)
			//		{
			//			vbx_dma_to_vector( vA1, Intrm_RESULT, 4096* sizeof(int16_t));
			//			vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
			//		}
					temp = TM + 122 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( RESULT + (i*32768) + (j*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 4)
			{			
				for (k=0;k<36;k++)
				{
					if(k < 35)
					{	
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + ((k+1)*32768), 4096 * sizeof(int16_t)); 
					}
					else //if(j<35)
					{
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + (16*32768), 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
			//		else if(j==35)
			//		{
			//			vbx_dma_to_vector( vA1, Intrm_RESULT+(16*4096), 4096* sizeof(int16_t));
			//			vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
			//		}
					temp = TM + 144 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( RESULT + (i*32768) + (j*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 5)
			{			
				for (k=0;k<6;k++)
				{
					if(k < 5)
					{	
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + ((k+1+16)*32768), 4096 * sizeof(int16_t)); 
					}
					else //if(j<35)
					{
						vbx_dma_to_vector( vA1, Intrm_RESULT+(j*4096) + 12*32768, 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
			//		else if(j==35)
			//		{
			//			vbx_dma_to_vector( vA1, Intrm_RESULT + (12*4096), 4096* sizeof(int16_t));
			//			vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
			//		}
					temp = TM + 196 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( RESULT + (i*32768) + (j*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 6)
			{			
				for (k=0;k<16;k++)
				{
					if(k < 15)
					{	
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + ((k+1+12)*32768), 4096 * sizeof(int16_t)); 
					}
					else// if(j<35)
					{
						vbx_dma_to_vector( vA1, Intrm_RESULT+(j*4096) + 18*32768, 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
			//		else if(j==35)
			//		{
			//			vbx_dma_to_vector( vA1, Intrm_RESULT + (18*4096), 4096* sizeof(int16_t));
			//			vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
			//		}
					temp = TM + 228 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( RESULT + (i*32768) + (j*4096), vD3, 4096 * sizeof(int16_t));			
			}
			if(i == 7)
			{			
				for (k=0;k<6;k++)
				{
					if(k < 5)
					{	
						vbx_dma_to_vector( vA1, Intrm_RESULT + (j*4096) + ((k+1+18)*32768), 4096 * sizeof(int16_t)); 
					}
					else if(j<7)
					{
						vbx_dma_to_vector( vA1, Intrm_RESULT+((j+1)*4096), 4096* sizeof(int16_t));	
						vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
					}
			//		else if(j==35)
			//		{
			//			vbx_dma_to_vector( vA1, Intrm_RESULT, 4096* sizeof(int16_t));
			//			vbx_dma_to_vector( vD3, zero_array, 4096 * sizeof(int16_t));
			//		}
					temp = TM + 270 + k;
					vbx(SVHS, VMUL, vD0 , *(temp), vA0);
					vbx(VVHS, VADD, vD1, vD0, vD1);						
					v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;			
				}
		//		v_tmp = vD1; vD1 = vD2; vD2 = v_tmp;	
				v_tmp = vD1; vD1 = vD3; vD3 = v_tmp;
				vbx_dma_to_host( RESULT + (i*32768) + (j*4096), vD3, 4096 * sizeof(int16_t));			
			}

		}
	}
/*
		temp = vB0 + j;
		vbx(SVHS, VMUL, vD3 , *(temp), vD0);
		vbx(VVHS, VADD, vD1, vD3, vD1);	

		temp = vB0+144+j;
		vbx(SVHS, VMUL, vD3 , *(temp), vD0);
		vbx(VVHS, VADD, vD1+2048, vD3, vD1+2048);	

		if (j > 11 && j < 18)
		{
	 	temp = vB0 + j + 36;
		vbx(SVHS, VMUL, vD3 , *(temp), vD0);
		vbx(VVHS, VADD, vD1+512, vD3, vD1+512);	
		}

		if (j > 7 && j < 24)
		{
		temp = vB0 + j + 72;
		vbx(SVHS, VMUL, vD3 , *(temp), vD0);
		vbx(VVHS, VADD, vD1+1024, vD3, vD1+1024);
		}

		if (j > 13 && j < 20)
		{
		temp = vB0 + j + 108;
		vbx(SVHS, VMUL, vD3 , *(temp), vD0);
		vbx(VVHS, VADD, vD1+1536, vD3, vD1+1536);
		}

		if (j > 15 && j < 22)
		{
		temp = vB0 + j + 180;
		vbx(SVHS, VMUL, vD3 , *(temp), vD0);
		vbx(VVHS, VADD, vD1+2560, vD3, vD1+2560);
		}

		if (j > 11 && j < 28)
		{
		temp = vB0 + j + 216;
		vbx(SVHS, VMUL, vD3 , *(temp), vD0);
		vbx(VVHS, VADD, vD1+3072, vD3, vD1+3072);
		}

		if (j > 17 && j < 24)
		{
		temp = vB0 + j + 252;
		vbx(SVHS, VMUL, vD3 , *(temp), vD0);
		vbx(VVHS, VADD, vD1+3584, vD3, vD1+3584);
		}
		v_tmp = vA0; vA0 = vA1; vA1 = v_tmp;		
		v_tmp = vD0; vD0 = vD4; vD4 = v_tmp;
	}
	vbx_dma_to_host( RESULT+(i*512), vD1, 512*8 * sizeof(int16_t)); 	 
	v_tmp = vD1; vD1 = vD_tmp; vD_tmp = v_tmp;
}
*/
	vbx_sync();
	stop_time = timestamp();
	printf("\n Total computation time = %ld\n", stop_time-start_time);
	f = fopen("Result_512_512.txt", "w");
	if (f == NULL)
	{
	    printf("Error opening file!\n");
	    exit(1);
	}
	for (k=0;k<8*32768;k++)
	{
		fprintf(f, "%d\n", RESULT[k]);
	}
	fclose(f);

	printf("\n------------------- END -------------------------------\n \n");
	vbx_sp_free();	
	vbx_shared_free(TM);
	vbx_shared_free(DATA);
	vbx_shared_free(Intrm_RESULT);
	vbx_shared_free(zero_array);
	vbx_shared_free(RESULT);
	fclose(RED_TM);
	fclose(MAT);
	}
	return 0;
}
