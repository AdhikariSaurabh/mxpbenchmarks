/********************************************************************* 
 * Application which communicates with the mem driver
 * by sending 64-bit samples - testing purpose
 * 
 * Written by Manikandan Govindarajan (GOVI0009@e.ntu.edu.sg)
 * Organisation : NTU
 ********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <unistd.h>
#include <inttypes.h>
#include <errno.h>
#include "pgm.h"
#include "vbx.h"
#include "vectorblox_mxp_lin.h"
#include "vbx_port.h"
#include "vbx_common.h"
#include "vbx_test.h"
/** Enable below define for measuring time in application or comment it*/
#define PROFILER
#define MXP
/** Enable below define for seeing the values read by this application or comment it*/
//#define DEBUG

/** Starting point of application*/
int main(int argc, char *argv[])
{
    /** flag 1 for writing*/
    int i,index;
    uint8_t *vb,*v_db,*temp;
    int g_size = 0;
    int max = 255;
    pgm_t opgm;
    pgm_t ipgm;
    #ifdef MXP
    printf("MXP Enabled\n");
    VectorBlox_MXP_Initialize("mxp0","cma");
    #else
    printf("MXP Disabled, APP is running entirely on ARM\n");
    #endif


    //Reading image
    readPGM(&ipgm,"lena.pgm");
    g_size = (ipgm.width * ipgm.height);// >> 3;
    
    printf("g_size = %d\n",g_size);

   /* for( i = 0; i < g_size; i++)
    {
	printf("in[%d] = 0x%x\n",i,ipgm.buf[i]);
    }*/

    opgm.width = ipgm.width;
    opgm.height = ipgm.height;
    opgm.buf = (uint8_t*)malloc(ipgm.width * ipgm.height * sizeof(uint8_t));

    //Processing image
    vbx_dcache_flush_all();

    vb = (uint8_t *)vbx_sp_malloc(30000*sizeof(uint8_t ));
    v_db = (uint8_t *)vbx_sp_malloc(30000*sizeof(uint8_t));

    vbx_dma_to_vector(vb,ipgm.buf,30000);

    vbx_set_vl(30000);

    for(index = 0; index < 3; index++)
    {
	if(index < 2)
	{	
	    vbx_dma_to_vector(v_db, ipgm.buf + (index + 1) * 30000, 30000); 			
	}

	vbx(SVBU, VSUB, vb, max, vb);
	vbx_dma_to_host(opgm.buf + (index * 30000), vb, 30000);
	temp = vb;
	vb = v_db;
	v_db = temp;
    }
    vbx_sync();

    //Writing image
    for( i = 0; i < g_size; i++)
    {
	printf("out[%d] = 0x%x\n",i,opgm.buf[i]);
    }
    writePGM(&opgm,"output.pgm");
    destroyPGM(&ipgm);
    destroyPGM(&opgm);
}
